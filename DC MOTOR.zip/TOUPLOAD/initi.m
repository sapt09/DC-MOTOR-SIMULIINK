%(J) moment of inertia of the rotor 0.01 kg.m^2
J = 0.01;
%(b) motor viscous friction constant 0.1 N.m.s
b = 0.1;
%(Ke) electromotive force constant 0.01 V/rad/sec
Ke = 0.01;
%(Kt) motor torque constant 0.01 N.m/Amp
Kt = 0.01;
%(R) electric resistance 1 Ohm
R = 1;
%(L) electric inductance 0.5 H
L = 0.5;